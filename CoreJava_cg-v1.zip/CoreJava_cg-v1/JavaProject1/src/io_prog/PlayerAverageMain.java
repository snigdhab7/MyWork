package io_prog;

import java.io.*;

import java.util.*;

public class PlayerAverageMain {

	private static Scanner scr;

	public static void main(String[] args) {
		scr = new Scanner(System.in);
		String fileName="src/io_prog/battingPerformances.txt";
		/*File fo=new File(fileName);
		try {
			if(fo.createNewFile())
			{
				try(FileWriter fw=new FileWriter(fo,true);BufferedWriter bw=new BufferedWriter(fw))
				{
					String str;
					while(scr.hasNextLine()) {
					str=scr.nextLine(); 
					bw.write(str); }
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
			}
		} catch (IOException e1) {
			e1.printStackTrace();
		} */
		String pname=scr.nextLine();
		File f=new File(fileName);
		if(f.exists())
		{
			try(FileReader fr=new FileReader(f);BufferedReader br=new BufferedReader(fr))
			{
				while(true) {
				float total=0,avg=0,c=0;
				String line=br.readLine();
				//System.out.println(line);
				if(line==null)
				{ break; }
				String[] playerArr=line.split("=");
				String name=playerArr[0];
				if(pname.compareTo(name)==0) {
				String scores=playerArr[1];
				String[] playerScore=scores.split(",");
				for(String s:playerScore)
				{ 
					if(s.charAt(s.length()-1)!='*')
					{   total+=Integer.parseInt(s);
						c++; }
					else
					{ total+=Integer.parseInt(s.substring(0,s.length()-1)); }
				}
				avg=total/c;
				System.out.print("Player Name: "+name+"\nAverage Score: "+avg+"\n\n");
				} }
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
