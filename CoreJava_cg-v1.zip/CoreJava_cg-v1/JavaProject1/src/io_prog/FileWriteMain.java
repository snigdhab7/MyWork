package io_prog;

import java.io.*;

public class FileWriteMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String fileName="messages.txt";
		try(OutputStream fout=new FileOutputStream(fileName,true);OutputStream bout=new BufferedOutputStream(fout))
		{
			String messages="GoodAfternoon";
			byte data[]=messages.getBytes();
			bout.write(data);
			System.out.println("Data written...");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

}
