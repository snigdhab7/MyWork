package io_prog;
import java.io.*;

public class BufferedReaderMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String fileName="greetings.txt";
		try(FileReader fr=new FileReader(fileName);
				BufferedReader br=new BufferedReader(fr))
		{
			while(true)
			{
				String line=br.readLine();
				if(line==null)
				{ break;  }
				System.out.println(line);
				}
			}catch(Exception e)
		{
				e.printStackTrace();
		}
	}
}
