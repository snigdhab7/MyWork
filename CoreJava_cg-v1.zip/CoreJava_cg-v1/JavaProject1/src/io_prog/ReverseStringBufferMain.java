package io_prog;

import java.io.*;


public class ReverseStringBufferMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String fileName=args[0];
		try(InputStream fin=new FileInputStream(fileName))
		{
		    StringBuffer strb=new StringBuffer();
			while(true)
			{   int ch=fin.read();
				strb.append((char)ch); 
				if(ch==-1)
				{ break; }	
			}
			int size=strb.length();
			for(int i=size-1;i>=0;i--)
			{ System.out.print(strb.charAt(i)); }
		} catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
}
