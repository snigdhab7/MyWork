package io_prog;

import java.io.*;

public class FileCopyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sourceFile = args[0];
		String destinationFile = args[1];
		File f=new File(sourceFile);
		if(f.exists())
		{
			try(InputStream fin=new FileInputStream(f);InputStream bin=new BufferedInputStream(fin))
			{
			long fileSize=f.length();
			byte fileData[]=new byte[(int)fileSize];
			fin.read(fileData);
			File fc=new File(destinationFile);
			if(fc.createNewFile())
			{
				try(OutputStream fout=new FileOutputStream(fc);OutputStream bout=new BufferedOutputStream(fout))
				{
					bout.write(fileData);
					System.out.println("File Data Copied !!");
				}catch(Exception ex)
				{
					ex.printStackTrace();
				}
			}
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}

}
