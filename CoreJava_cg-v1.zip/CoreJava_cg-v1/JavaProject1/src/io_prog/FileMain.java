package io_prog;

import java.io.*;

public class FileMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String fileName="greetings.txt";
		File f=new File(fileName);
		if(f.exists())
		{ 
			try(FileInputStream fin=new FileInputStream(f)) 
			{
				long fileSize=f.length();
				byte fileData[]=new byte[(int)fileSize];
				fin.read(fileData);
				String fileInfo=new String(fileData);
				System.out.println(fileInfo);
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}

}
