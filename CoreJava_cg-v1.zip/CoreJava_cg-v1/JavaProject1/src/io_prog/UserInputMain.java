package io_prog;
import java.util.Scanner;

public class UserInputMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter 1st no: ");
		int n1=scr.nextInt();
		System.out.println("Enter 2nd no: ");
		int n2=scr.nextInt();
		int sum=n1+n2;
		System.out.println("Sum: "+sum);
		scr.close();
	}

}
