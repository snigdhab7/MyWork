package io_prog;
import java.io.*;

public class BookDeserializationMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(FileInputStream fin=new FileInputStream("books.txt");ObjectInputStream in=new ObjectInputStream(fin))
		{
			Object obj=in.readObject();
			Book bk=(Book)obj;
			String title=bk.getTitle();
			float price=bk.getPrice();
			System.out.println("Title: "+title);
			System.out.println("Price: "+price);
		}
	 catch(Exception ex)
	{
		ex.printStackTrace();
	}
}
}
