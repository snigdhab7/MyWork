package io_prog;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class FileReadMain {

	public static void main(String[] args){
		// TODO Auto-generated method stub
		String fileName="greetings.txt"; // fileName="d://myfiles//"
		try(InputStream fin=new FileInputStream(fileName) ; InputStream bin=new BufferedInputStream(fin)) {
		while(true)
			{ int data=bin.read(); 
			  if(data==-1)
				  { break; } 
		System.out.print((char)data);
			}
		}catch(FileNotFoundException e)
		{ e.printStackTrace(); }
		catch(IOException e) {
			e.printStackTrace();
		}
	/*	finally { 
			try {
			fin.close(); }
			catch(IOException e)
			{
				e.printStackTrace(); 
			}
		}  */
	}
}
