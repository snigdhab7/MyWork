package io_prog;
import java.io.*;
public class BookSerializationMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(FileOutputStream fout=new FileOutputStream("books.txt");ObjectOutputStream out=new ObjectOutputStream(fout)){
			Book currentBook=new Book();
			out.writeObject(currentBook);
			System.out.println("Book object serialized...");
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
