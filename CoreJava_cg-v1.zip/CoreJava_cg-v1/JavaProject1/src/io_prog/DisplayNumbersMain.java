package io_prog;

import java.io.*;

public class DisplayNumbersMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String fileName="src/io_prog/numbers.txt";
		try(InputStream fin=new FileInputStream(fileName) ; InputStream bin=new BufferedInputStream(fin))
		{ 
			String str=new String();
			int sum=0;
			while(true)
			{ 
				int data=bin.read();
				str+=(char)data;
				if(data==-1)
				{
					break;
				}
			}
			str=str.substring(0,str.length()-1);
			String[] arrStr=str.split(",");
			for(String s:arrStr)
			{ 
				//System.out.println(s.charAt(s.length()-1));
				sum+=Integer.parseInt(s); }
			System.out.println("Total Sum:"+sum);
		}
		catch(FileNotFoundException e)
		{ e.printStackTrace(); }
		catch(IOException e)
		{ e.printStackTrace(); }
	}

}
