package io_prog;

import java.io.*;
import java.lang.*;
import java.util.*;

public class Book implements Comparable<Book> , Serializable {
		private String title;
		private float price;
		public Book()
		{
			title="Java Complete Reference";
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public float getPrice() {
			return price;
		}
		public void setPrice(float price) {
			this.price = price;
		}
		@Override
		public String toString() {
			return "Book [title=" + title + ", price=" + price + "]";
		}
		public Book(String title, float price) {
			super();
			this.title = title;
			this.price = price;
		}
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + Float.floatToIntBits(price);
			result = prime * result + ((title == null) ? 0 : title.hashCode());
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Book other = (Book) obj;
			if (Float.floatToIntBits(price) != Float.floatToIntBits(other.price))
				return false;
			if (title == null) {
				if (other.title != null)
					return false;
			} else if (!title.equals(other.title))
				return false;
			return true;
		}
		@Override
		public int compareTo(Book book2) {
			// TODO Auto-generated method stub
			String title1=title;
			String title2=book2.title;
			int comparison=title1.compareTo(title2);
			return comparison;
		}
		
}
