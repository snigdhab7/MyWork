package interfaces;

public class LargeBisleriBottle extends BisleriPack implements BisleriBottle {

	float volume,cost;
	
	public LargeBisleriBottle(int quantity,float volume, float cost) {
		super(quantity);
		this.volume = volume;
		this.cost = cost;
	}

	@Override
	public float getCost() {
		// TODO Auto-generated method stub
		return cost;
	}

	@Override
	public float getVolume() {
		// TODO Auto-generated method stub
		return volume;
	}

}
