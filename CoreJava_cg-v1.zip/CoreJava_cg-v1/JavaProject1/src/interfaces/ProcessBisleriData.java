package interfaces;

public class ProcessBisleriData implements BisleriDataProcessor {
	
	
	public ProcessBisleriData() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public float processBisleriData(BisleriPack bispack[]) {
		// TODO Auto-generated method stub
		float totalCost=0,totalVolume=0;
		int size=bispack.length;
		for(BisleriPack bp:bispack)
		{ totalCost+=bp.getCost()*bp.getQuantity();
		  totalVolume+=bp.getVolume()*bp.getQuantity();
		}
		System.out.print("Total Volume: "+totalVolume/1000+"L"+"\nTotal Cost: "+totalCost+"INR");
		return 0.0f;
	}

}
