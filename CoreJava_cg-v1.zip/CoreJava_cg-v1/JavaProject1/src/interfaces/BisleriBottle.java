package interfaces;

public interface BisleriBottle { 
	float volume=0,cost=0;
	float getVolume();
	float getCost();
}
