package interfaces;

public interface AreaCalculator {
	float PI=3.14f;	
	float getArea();
}
