package interfaces;

public class AreaCalculatorMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		AreaCalculator ac;
		ac=new CircularAreaCalculator(5);
		System.out.println("Area of circle: "+ac.getArea());
		
		ac=new RectangularAreaCalculator(10,6);
		System.out.println("Area of rectangle: "+ac.getArea());
	}

}
