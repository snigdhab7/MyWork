package interfaces;

public class CircularAreaCalculator implements AreaCalculator {
	int radius;
	
	public CircularAreaCalculator(int radius)
	{ super();
	  this.radius=radius;
	}
	
	@Override
	public float getArea() {
		return PI*radius*radius;
	}

}
