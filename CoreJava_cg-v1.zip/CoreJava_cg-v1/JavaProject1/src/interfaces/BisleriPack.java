package interfaces;

public class BisleriPack implements BisleriBottle { 
	//BisleriBottle bottleType=null;
	int quantity=0;
	float cost=0,volume=0;
	
	public BisleriPack(int quantity) {
		super();
		//this.bottleType = bottleType;
		this.quantity = quantity;
	}
	//public BisleriBottle getBottleType() {
		//return bottleType;
	//}
	//public void setBottleType(BisleriBottle bottleType) {
	//	this.bottleType = bottleType;
//	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public float getCost() {
		// TODO Auto-generated method stub
		return cost;
	}
	@Override
	public float getVolume() {
		// TODO Auto-generated method stub
		return volume;
	}


}
