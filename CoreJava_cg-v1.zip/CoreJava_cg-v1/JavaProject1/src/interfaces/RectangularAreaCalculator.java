package interfaces;

public class RectangularAreaCalculator implements AreaCalculator {
	private int length,breadth;
	
	public RectangularAreaCalculator(int length,int breadth) {
		super();
		this.length=length;
		this.breadth=breadth;
	}
	
	@Override
	public float getArea() {
		return length*breadth;
	}

}
