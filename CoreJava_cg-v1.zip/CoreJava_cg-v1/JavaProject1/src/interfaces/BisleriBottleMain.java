package interfaces;

public class BisleriBottleMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BisleriPack b[]=new BisleriPack[3];
		b[0]=new SmallBisleriBottle(5,200.0f,10.0f);
		b[1]=new MediumBisleriBottle(3,350.0f,15.0f);
		b[2]=new LargeBisleriBottle(10,500.0f,20.0f);
		
		ProcessBisleriData pbd=new ProcessBisleriData();
		pbd.processBisleriData(b);
		
	}

}
