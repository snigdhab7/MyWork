package interfaces;

public interface BisleriDataProcessor {
	float processBisleriData(BisleriPack bp[]);
}
