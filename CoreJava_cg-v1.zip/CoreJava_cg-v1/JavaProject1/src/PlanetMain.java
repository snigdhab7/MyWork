import exceptions.NegativeMoonsException;

public class PlanetMain {
	
	public static void changePlanet(Planet oldPlanet) {
	/*	oldPlanet.setName("Jupiter");
		oldPlanet.setMoons(16);  */
  	}
	
	public static void main(String[] args) {
		/*
		Planet p1 = new Planet();
		Planet p2 = new Planet("Neptune",2);
		Planet p3 = new Planet(0,"Pluto");
		
		//p1.setName("Jupiter");
		//p1.setMoons(16);
		
		p2.setName("Saturn");
		p2.setMoons(28);
		
		System.out.println(p1.getName() + " has " + p1.getMoons() + " moons.");
		System.out.println(p2.getName() + " has " + p2.getMoons() + " moons.");
		System.out.println(p3.getName() + " has " + p3.getMoons() + " moons.");
		//System.out.println(p2.getName() + " has " + p2.getMoons() + " moons.");
		
		p1.increaseMoonsByOne();
		System.out.println(p1.getPlanetData());
		 
		for(int a=1;a<=5;a++)
		{ Planet p1=new Planet(); }
		
		System.out.println("Current Planet Count: "+Planet.getTotalPlanets());
		
		for(int a=1;a<=3;a++)
		{ Planet p1=new Planet(); }
		System.out.println("New Planet Count: "+Planet.getTotalPlanets());
		
		Planet p1=new Planet("Mars",2);
		Planet p2=new Planet(5,"Uranus");
		System.out.println("Planet Final Count: "+Planet.getTotalPlanets()); 
		
		Planet p1=new Planet("Saturn",14);
		Planet p2=new Planet("Saturn",14);
		//Planet p2=p1;
		if (p1.equals(p2))
		{ System.out.println("Equal"); }
		else
		{ System.out.println("Unequal");
		}
		System.out.println(p1);
		changePlanet(p1); 
		System.out.println(p1.getPlanetData());  */
		Planet p1=null,p2=null;
		p1=new Planet();
		try { 
			p2=new Planet("Mars",-4);
		} catch(NegativeMoonsException e ) {
			String msg=e.getMessage();
			System.out.println(msg);
		}
		finally {
			System.out.println(p1);
			if(p2!=null)
			{ System.out.println(p2); }
		}
	}
}

