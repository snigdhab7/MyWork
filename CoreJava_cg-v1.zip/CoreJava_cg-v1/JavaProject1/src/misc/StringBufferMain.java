package misc;

public class StringBufferMain {
	public static void main(String args[])
	{
		StringBuffer sb=new StringBuffer();
		sb.append("Hello");
		sb.append("Hi");
		sb.append(100);
		sb.append(100.56f);
		sb.append(100.54);
		sb.append('Y');
		sb.append(true);
		sb.append("Done");
		System.out.println(sb);
	}
	
}