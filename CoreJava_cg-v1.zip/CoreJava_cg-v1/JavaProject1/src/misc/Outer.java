package misc;

public class Outer {
	private int x;
	private static int y;
	public void print()
	{ class Message {
		void printMessage() {
			System.out.println("Welcome to local class");
		}
	}
	}
	public static class Inner {
		public void set()
		{
			y=20;
			System.out.println(y);
		}
	}
		public class Nested {
			public void set() {
			x=10;
			y=20;
			System.out.println(x+" "+y);
		}
		
		}	
} 

