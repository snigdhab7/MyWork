package misc;

public class OuterMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Outer.Inner in=new Outer.Inner();
		in.set();

	}

}
