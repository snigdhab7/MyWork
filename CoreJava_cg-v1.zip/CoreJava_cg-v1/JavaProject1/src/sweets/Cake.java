package sweets;
import food_item.Fruit;

public class Cake {
	public static void makePineappleCake(){ 
		Fruit pineapple=new Fruit();
	}
}
