package sweets.desserts;
import food_item.Fruit;

public class IceCream {
	public static void makeMangoIceCream(){
		Fruit mango=new Fruit();
	}
}
