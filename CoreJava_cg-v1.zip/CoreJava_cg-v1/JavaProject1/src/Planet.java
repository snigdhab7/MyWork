import exceptions.NegativeMoonsException;

public class Planet {
	private String name;
	private int moons;
	private static int totalPlanets;
	
	public static int getTotalPlanets()
	{ return totalPlanets; }
	
	public Planet(){
		name="Earth";
		moons=1;
		totalPlanets++;
	}
	
	public Planet(String name, int moons) throws NegativeMoonsException {
		this.name = name;
		if(moons<0) {
			NegativeMoonsException ne=new NegativeMoonsException("Moons cannot be negative",moons);
			throw ne;
		}
		this.moons = moons;
		totalPlanets++;
	}

	public Planet(int moons, String name) throws NegativeMoonsException {
		this.name = name;
		if(moons<0) {
			NegativeMoonsException ne=new NegativeMoonsException("Moons cannot be negative",moons);
			throw ne;
		}
		this.moons = moons;
		totalPlanets++;
	}
	
	
	@Override
	public String toString() {
		return "Planet [moons=" + moons + ", name=" + name + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + moons;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Planet other = (Planet) obj;
		if (moons != other.moons)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMoons() {
		return moons;
	}
	public void setMoons(int moons) throws NegativeMoonsException {
		if(moons<0) {
			NegativeMoonsException ne=new NegativeMoonsException("Moons cannot be negative",moons);
			throw ne;
		}
		this.moons = moons;
	}
	
	public void increaseMoonsByOne(){
		moons++;
	}
	
	public String getPlanetData()
	{
		String data = "Name: " + name + ", Moons: " + moons;
		return data;
	}
}
