package exceptions;

public class NegativeMoonsException extends Exception {
	private int negativeValue;
	public NegativeMoonsException(String errorMessage,int negativeValue) {
		super(errorMessage);
		this.negativeValue=negativeValue;
	}
	public String getMessage()
	{ String msg=super.getMessage();
	  msg+=" : "+negativeValue;
	  return msg;
	}
}
