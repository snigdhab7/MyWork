package exceptions;

public class ExceptionMain {
	public static void main(String args[]) {
	try {
	String s1=args[0];
	String s2=args[1];
	int n1=Integer.parseInt(s1);
	int n2=Integer.parseInt(s2);
	int divide=n1/n2;
	System.out.println(divide);
	}
	catch(ArrayIndexOutOfBoundsException | ArithmeticException ex) {
		if (ex instanceof ArrayIndexOutOfBoundsException) {
		System.out.println("Enter at least two values."); }
		else 
		{ System.out.println("Enter 2nd value non-zero"); }
	}
	/*catch(ArithmeticException ex)
	{ System.out.println("Enter 2nd value non-zero");
	}*/
	catch(Exception e) {
		System.out.println("General error");
	}
	//finally { 
		System.out.println("This statement is always executed !!");
	//}
	}
}
