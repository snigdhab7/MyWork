
public class PersonMain {

	
	public static void main(String[] args) {
		
		Person p1 = new Person();
		
		p1.setFirstname("Avani");
		p1.setLastname("Bhatnagar");
		p1.setAnnualIncome(680000);
		p1.setAge((byte) 22);
		p1.setMarried(false);
		p1.setWeight(60.3f);
		p1.setHeight(1.54);
		
		System.out.println("Hello!! My name is " + p1.getFullName());
		System.out.println("My annual income is " + p1.getAnnualIncome());
		System.out.println("My married status " + p1.isMarried());
		System.out.println("My BMI is " + p1.getBMI());
		System.out.println("senior Citizen?: " + p1.isSeniorCitizen());
		System.out.println("then age? " + p1.getAge());

	}

}
