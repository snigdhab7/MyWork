package food_menu;
import food_item.Fruit;
import food_item.FruitJuice;
import sweets.desserts.IceCream;

public class MenuCard {


	public static void main(String[] args) {
		FruitJuice orangeJuice=new FruitJuice();
		IceCream mangoIceCream=new IceCream();
		Fruit apple=new Fruit(); 

	}

}
