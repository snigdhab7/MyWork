package containment;
// Composition
public class FoodService {
	private String caterer;
	private int plateCount,ratePerPlate;
	public FoodService() { 
		caterer="Swad";
		plateCount=200;
		ratePerPlate=250;
	}
	public FoodService(String caterer,int plateCount,int ratePerPlate)
	{ this.caterer=caterer;
	  this.plateCount=plateCount;
	  this.ratePerPlate=ratePerPlate; 
	}
	
	public void setCaterer(String caterer)
	{ this.caterer=caterer; }
	public String getCaterer()
	{ return this.caterer; }
	public void setPlateCount(int plateCount)
	{ this.plateCount=plateCount; }
	public int getPlateCount()
	{ return this.plateCount; }
	public void setRatePerPlate(int ratePerPlate)
	{ this.ratePerPlate=ratePerPlate; }
	public int getRatePerPlate()
	{ return ratePerPlate; }
	
	public int generateBillAmount() {
		int billAmount=plateCount*ratePerPlate;
		return billAmount;
	}
}
