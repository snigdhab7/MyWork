package containment;

public class Event {
		private String name,location;
		private int otherExpenses;
		private FoodService foodArrangement;
		private MusicService musicArrangement;
		
		public Event() { 
			name="Seminar on Java";
			location="Pune";
			otherExpenses=150000;
			foodArrangement=new FoodService();
		}
		public Event (String name,String location, int otherExpenses, FoodService foodArrangement, MusicService musicArrangement)
		{ this.name=name;
		  this.location=location;
		  this.otherExpenses=otherExpenses;
		  this.foodArrangement=foodArrangement;
		  this.musicArrangement=musicArrangement;
		}
		
		public int getTotalExpenses() {
			int foodExpenses=foodArrangement.generateBillAmount();
			int musicExpenses=0;
			if (musicArrangement != null)
			{ musicExpenses=musicArrangement.generateBillAmount(); }
			int totalExpenses=otherExpenses+foodExpenses+musicExpenses;
			return totalExpenses;
		}
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getLocation() {
			return location;
		}
		public void setLocation(String location) {
			this.location = location;
		}
		public int getOtherExpenses() {
			return otherExpenses;
		}
		public void setOtherExpenses(int otherExpenses) {
			this.otherExpenses = otherExpenses;
		}
		public FoodService getFoodArrangement() {
			return foodArrangement;
		}
		public void setFoodArrangement(FoodService foodArrangement) {
			this.foodArrangement = foodArrangement;
		}
		public MusicService getMusicArrangement() {
			return musicArrangement;
		}
		public void setMusicArrangement(MusicService musicArrangement) {
			this.musicArrangement = musicArrangement;
		}
}