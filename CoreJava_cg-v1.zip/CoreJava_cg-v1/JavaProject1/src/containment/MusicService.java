package containment;
// Aggregation
public class MusicService {
	private String musician;
	private int hours,ratePerHour;
	public MusicService() { 
		musician="A.R.Rahman";
		hours=2;
		ratePerHour=4500;
	}
	public MusicService(String musician,int hours,int ratePerHour)
	{ this.musician=musician;
	  this.hours=hours;
	  this.ratePerHour=ratePerHour; 
	}
	
	public void setmusician(String musician)
	{ this.musician=musician; }
	public String getmusician()
	{ return this.musician; }
	public void sethours(int hours)
	{ this.hours=hours; }
	public int gethours()
	{ return this.hours; }
	public void setRatePerHour(int ratePerHour)
	{ this.ratePerHour=ratePerHour; }
	public int getRatePerHour()
	{ return ratePerHour; }

	public int generateBillAmount() {
		int billAmount=hours*ratePerHour;
		return billAmount;
	}
	

	}

