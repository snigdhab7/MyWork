package containment;

public class EventMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FoodService fdService=new FoodService();
		MusicService msService=new MusicService();
		
		Event event1=new Event();
		Event event2=new Event("Dandiya 2019","Mumbai",250000,fdService,msService);
		
		System.out.println("1st Event Expenses: "+event1.getTotalExpenses());
		System.out.println("2nd Event Expenses: "+event2.getTotalExpenses());
		
		FoodService fs1=event1.getFoodArrangement();
		String caterer1=fs1.getCaterer();
		System.out.println(caterer1);
		
		// OR 
		System.out.println(event1.getFoodArrangement().getCaterer().toUpperCase()); // Object Graph Navigation

	}

}
