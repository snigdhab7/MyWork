package inheritance;

public class CricketPlayer extends Player {
	private int runs;
	
	public CricketPlayer() {
		runs=10874;
	}

	@Override
	public String toString() {
		return "CricketPlayer [runs=" + runs + ", toString()="
				+ super.toString() + "]";
	}

	public CricketPlayer(String name, int age, int runs) {
		super(name, age);
		this.runs = runs;
	}

	public int getRuns() {
		return runs;
	}

	public void setRuns(int runs) {
		this.runs = runs;
	}

}
