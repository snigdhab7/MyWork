package inheritance;

public class PlayerMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		CricketPlayer cp=new CricketPlayer();
		System.out.println(cp.getName());
		System.out.println(cp.getAge());
		System.out.println(cp.getRuns());
	}

}
