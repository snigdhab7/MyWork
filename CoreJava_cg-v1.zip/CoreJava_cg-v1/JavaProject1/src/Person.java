
public class Person {
		private String firstname, lastname;
		private int annualIncome;
		private boolean married;
		private byte age;
		private float weight,height;
		
		public String getFullName(){
			return firstname + " " + lastname;
		}
		public boolean isSeniorCitizen(){
			if(age>=60)
				return true;
			return false;
		}
		public float getBMI(){
			return (weight/(height*height));
		}
		
		public String getFirstname() {
			return firstname;
		}
		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}
		public String getLastname() {
			return lastname;
		}
		public void setLastname(String lastname) {
			this.lastname = lastname;
		}
		public int getAnnualIncome() {
			return annualIncome;
		}
		public void setAnnualIncome(int annualIncome) {
			this.annualIncome = annualIncome;
		}
		public boolean isMarried() {
			return married;
		}
		public void setMarried(boolean married) {
			this.married = married;
		}
		public byte getAge() {
			return age;
		}
		public void setAge(byte age) {
			this.age = age;
		}
		public float getWeight() {
			return weight;
		}
		public void setWeight(float weight) {
			this.weight = weight;
		}
		public float getHeight() {
			return height;
		}
		public void setHeight(double d) {
			this.height = (float) d;
		}
}
