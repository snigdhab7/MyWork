package collections;
import java.io.*;

import java.util.Properties;

import javax.swing.JFrame;

public class PropertiesMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String fileName="src/collections/window.properties";
		Properties windowProps=new Properties();
		String windowTitle=null;
		int windowHeight=0,windowWidth=0;
		try(FileInputStream fin=new FileInputStream(fileName))
		{
		  	windowProps.load(fin);
		  	windowTitle=windowProps.getProperty("title");
		  	windowHeight=Integer.parseInt(windowProps.getProperty("height"));
		  	windowWidth=Integer.parseInt(windowProps.getProperty("width"));
		  	
		}catch(Exception e)
		{ e.printStackTrace(); }
		System.out.println(windowTitle);
		System.out.println(windowHeight);
		System.out.println(windowWidth);
		JFrame f1=new JFrame();
		f1.setTitle(windowTitle);
		f1.setSize(windowWidth,windowHeight);
		f1.setVisible(true);
		f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
