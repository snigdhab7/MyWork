package collections;

public class GenericsMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Adder<String> strAdder=new StringAdder();
		Adder<Integer> intAdder=new IntegerAdder();
		
		System.out.println(strAdder.doAdd("Hello", "Hi"));
		System.out.println(strAdder.doAdd("Hello", "Hi","Bye"));
		System.out.println(intAdder.doAdd(20,30));
		System.out.println(intAdder.doAdd(20,30,10));
	}
}
