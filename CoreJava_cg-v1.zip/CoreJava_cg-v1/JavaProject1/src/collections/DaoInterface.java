package collections;

import java.util.Collection;

public interface DaoInterface<T, K> {
	void add(T t);
	T getByIdentity(K id);
	Collection<T> getAll();
	void update(T t);
	void deleteByIdentity(K id);
}
