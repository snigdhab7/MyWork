package collections;

public class PersonByIdentityMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DaoInterface<Person,Integer> idao=new PersonDaoImpl();
		Person p=idao.getByIdentity(106);
		if(p!=null)
		{ System.out.println(p); }
		else {
			System.out.println("Person not found");
		}
	}
}
