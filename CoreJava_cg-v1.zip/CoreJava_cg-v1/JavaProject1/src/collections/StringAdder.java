package collections;

public class StringAdder implements Adder<String> {

	@Override
	public String doAdd(String t1, String t2) {
		// TODO Auto-generated method stub
		return t1+t2;
	}
 
	@Override
	public String doAdd(String t1, String t2, String t3) {
		// TODO Auto-generated method stub
		return t1+t2+t3;
	}

}
