package collections;

import java.util.*;

import io_prog.Book;

public class TreeSetMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*SortedSet<String> flowers=new TreeSet<String>();
		flowers.add("Lotus");
		flowers.add("Jasmine");
		flowers.add("Rose");
		flowers.add("Lilly");
		flowers.add("Sunflower");
		//flowers.add(161);
		
		for(String flower:flowers)
		{
			System.out.println(flower);
		}*/
		Comparator<Book> comp1=new BookComparatorTitleDesc();
		
		SortedSet<Book> books=new TreeSet<>(comp1);
		Book b1=new Book("JAVA", 450.5f);
		Book b2=new Book("C++", 350.5f);
		Book b3=new Book("Java Reference", 550.5f);
		Book b4=new Book("Python", 230.0f);
		books.add(b1);
		books.add(b2);
		books.add(b3);
		books.add(b4);
		for(Book bk:books)
		{
			System.out.println(bk);
		}

	}

}
