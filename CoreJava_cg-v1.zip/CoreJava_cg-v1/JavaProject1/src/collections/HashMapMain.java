package collections;

import java.util.*;
import io_prog.Book;
public class HashMapMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,Book> booksData=new HashMap<>();
		Book b1=new Book("Book 1", 450.5f);
		Book b2=new Book("Book 2", 350.5f);
		Book b3=new Book("Book 3", 550.5f);
		Book b4=new Book("Book 4", 230.0f);
		booksData.put("bk1", b1);
		booksData.put("bk2", b2);
		booksData.put("bk3", b3);
		booksData.put("bk4", b4);
		
		//Fetching Values based upon keys
		Set<String> keys=booksData.keySet();
		for(String key:keys)
		{
			Book currentBook= booksData.get(key);
			System.out.println("Book ID: "+key+" Book Details: "+currentBook);
		}
		
		//Fetching Values directly
		Collection<Book> books=booksData.values();
		for(Book bk:books)
		{
			System.out.println("Books Details: "+bk);
		}
	}

}
