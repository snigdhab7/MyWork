package collections;

public class PersonAddMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DaoInterface<Person,Integer> idao=new PersonDaoImpl();
		Person p1=new Person(101, "James", "james@oracle.com");
		Person p2=new Person(102, "Lewis", "lewis@oracle.com");
		Person p3=new Person(103, "Stacy", "stacy@oracle.com");
		idao.add(p1);
		idao.add(p2);
		idao.add(p3);
	}

}
