package collections;

public interface Adder<T> {
	T doAdd(T t1,T t2);
	T doAdd(T t1,T t2,T t3);
}
