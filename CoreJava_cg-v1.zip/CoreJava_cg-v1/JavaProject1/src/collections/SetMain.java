package collections;
import java.util.*;

import io_prog.Book;

public class SetMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Book> books=new HashSet<>();
		books.add(new Book("Book1",100));
		books.add(new Book("Book2",200));
		books.add(new Book("Book3",300));
		books.add(new Book("Book2",200));
		/*books.add("Java Complete Reference");
		books.add("Let us C");
		books.add("Thinking in Java");
		
		books.add("Effective Java");
		books.add("Java with ReST");
		books.add("Thinking in Java");
		books.add("Effective Java");*/
		
		for(Book book:books)
		{
			System.out.println(book);
		}

	}

}
