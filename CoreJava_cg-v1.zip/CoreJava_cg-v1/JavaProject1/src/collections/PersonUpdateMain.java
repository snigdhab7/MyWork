package collections;

public class PersonUpdateMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DaoInterface<Person,Integer> idao=new PersonDaoImpl();
		Person p=idao.getByIdentity(101);
		if(p!=null)
		{
			p.setPersonName("Himanshu");
			p.setPersonEmail("himanshu@oracle.com");
			idao.update(p);
		}
		else
		{
			System.out.println("Person Not Found");
		}

	}

}
