package collections;

import java.util.Collection;

public class PersonAll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DaoInterface<Person,Integer> idao=new PersonDaoImpl();
		Collection<Person> p=idao.getAll();
		System.out.println(p);
	}

}
