package collections;

import java.util.Iterator;
import java.util.Vector;
import io_prog.Book;


public class VectorMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector dataValues=new Vector();
		dataValues.add("Welcome");
		dataValues.add(100);
		dataValues.add(true);
		dataValues.add(100.0f);
		dataValues.add('Y');
		dataValues.add(new Book());
		dataValues.add(100);
		dataValues.add("Welcome");
		dataValues.add(new Book());
		
		Iterator it=dataValues.iterator();
		while(it.hasNext())
		{
			Object obj=it.next();
			System.out.println(obj);
		}
		
		/*int size=dataValues.size();
		for(int i=0;i<size;i++)
		{
			Object value=dataValues.get(i);
			System.out.println(value);
		}
		for(Object value:dataValues)
		{
			System.out.println(value);
		}*/
	}

}
