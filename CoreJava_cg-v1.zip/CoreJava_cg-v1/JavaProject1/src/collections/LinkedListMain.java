package collections;

import java.util.LinkedList;

import io_prog.Book;

public class LinkedListMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList dataValues=new LinkedList();
		dataValues.add("Welcome");
		dataValues.add(100);
		dataValues.add(true);
		dataValues.add(100.0f);
		dataValues.add('Y');
		dataValues.add(new Book());
		dataValues.add(100);
		dataValues.add("Welcome");
		dataValues.add(new Book());
		dataValues.addFirst("Good Morning");
		
		System.out.println(dataValues.getFirst());
		
		for(Object value:dataValues)
		{
			System.out.println(value);
		}
		
	}

}
