package collections;
import java.util.*;

public class TyeSafeCollectionsMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> fruits = new ArrayList<>();
		fruits.add("Mango");
		fruits.add("Apple");
		fruits.add("Banana");
		fruits.add("watemelon");
		fruits.add("Orange");
		
		for(String fruit:fruits)
		{
			System.out.println(fruit.toUpperCase());
		}
			
	}

}
