package collections;
import java.util.*;

import io_prog.Book;

public class ArrayListMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList dataValues=new ArrayList();
		dataValues.add("Welcome");
		dataValues.add(100);
		dataValues.add(true);
		dataValues.add(100.0f);
		dataValues.add('Y');
		dataValues.add(new Book());
		dataValues.add(100);
		dataValues.add("Welcome");
		dataValues.add(new Book());
		for(Object value:dataValues)
		{
			System.out.println(value);
		}

	}

}
