package collections;

public class IntegerAdder implements Adder<Integer> {

	@Override
	public Integer doAdd(Integer t1, Integer t2) {
		// TODO Auto-generated method stub
		return t1+t2;
	}

	@Override
	public Integer doAdd(Integer t1, Integer t2, Integer t3) {
		// TODO Auto-generated method stub
		return t1+t2+t3;
	}

}
