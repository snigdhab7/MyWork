package collections;

import java.util.*;

public class Movie {
	String title;
	int yearOfRelease;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getYearOfRelease() {
		return yearOfRelease;
	}
	public void setYearOfRelease(int yearOfRelease) {
		this.yearOfRelease = yearOfRelease;
	}
	public Movie(String title, int yearOfRelease) {
		super();
		this.title = title;
		this.yearOfRelease = yearOfRelease;
	}
	@Override
	public String toString() {
		return "Movie [title=" + title + ", yearOfRelease=" + yearOfRelease + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + yearOfRelease;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		if (yearOfRelease != other.yearOfRelease)
			return false;
		return true;
	}
	
	public static void movieSearch(Map<String,Movie> movs)
	{
		Scanner scr=new Scanner(System.in);
		int yr=0,minyr=0,maxyr=0;
		System.out.println("Enter Specific Year to search for Movies: ");
		yr=scr.nextInt();
		System.out.println("Enter Lower Value of Range of year to search for Movies: ");
		minyr=scr.nextInt();
		System.out.println("Enter Lower Value of Range of year to search for Movies: ");
		maxyr=scr.nextInt();
		
		Set<String> keys=movs.keySet();
		
		System.out.println("Movies Released in "+yr+" :");
		for(String key:keys)
		{
			Movie currentMovie=movs.get(key);
			if(currentMovie.getYearOfRelease()==yr)
			{ System.out.println(currentMovie.getTitle()); }
		}
		System.out.println("Movies Released between "+minyr+" and "+maxyr+" :");
		for(String key:keys)
		{
			Movie currentMovie=movs.get(key);
			if(currentMovie.getYearOfRelease()>=minyr && currentMovie.getYearOfRelease()<=maxyr)
			{ System.out.println(currentMovie.getTitle()); }
		}
		System.out.println("Movies Released in Leap Years :");
		for(String key:keys)
		{
			Movie currentMovie=movs.get(key);
			if(isLeapYear(currentMovie.getYearOfRelease()))
			{  System.out.println(currentMovie.getTitle()); }
		}
		scr.close();
	}
	public static boolean isLeapYear(int year)
	{
		boolean flag=false;
		if(year%400==0) { if(year%100==0) { if(year%4==0) { flag=true; } } }
		return flag;
	}
}
