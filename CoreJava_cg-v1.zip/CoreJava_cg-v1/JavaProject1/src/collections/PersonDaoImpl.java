package collections;

import java.io.*;
import java.util.*;

public class PersonDaoImpl implements DaoInterface<Person, Integer> {

	@Override
	public void add(Person pers) {
		// TODO Auto-generated method stub
		String fileName="persons.txt";
		File f=new File(fileName);
		Map<Integer,Person> personMap=null;
		if(f.exists())
		{
			try(FileInputStream fin=new FileInputStream(f);
					ObjectInputStream in=new ObjectInputStream(fin))
			{
				Object obj=in.readObject();
				personMap=(Map<Integer,Person>)obj;
				
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}
		else
		{
			personMap=new HashMap<Integer,Person>();
		}
		personMap.put(pers.getPersonId(), pers);
		try(FileOutputStream fout=new FileOutputStream("persons.txt");
				ObjectOutputStream out=new ObjectOutputStream(fout))
		{
			out.writeObject(personMap);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		System.out.println("Person Added Successfully !!");
	}

	@Override
	public Person getByIdentity(Integer id) {
		// TODO Auto-generated method stub
		Person foundPerson=null;
		String fileName="persons.txt";
		File f=new File(fileName);
		Map<Integer,Person> personMap=null;
		if(f.exists())
		{
			try(FileInputStream fin=new FileInputStream(f);
					ObjectInputStream in=new ObjectInputStream(fin))
			{
				Object obj=in.readObject();
				personMap=(Map<Integer,Person>)obj;
				
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}
			foundPerson = personMap.get(id);
		}
		return foundPerson;
	}

	@Override
	public Collection<Person> getAll() {
		// TODO Auto-generated method stub
		String fileName="persons.txt";
		File f=new File(fileName);
		Map<Integer,Person> personMap=null;
		if(f.exists())
		{
			try(FileInputStream fin=new FileInputStream(f);
					ObjectInputStream in=new ObjectInputStream(fin))
			{
				Object obj=in.readObject();
				personMap=(Map<Integer,Person>)obj;
				
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}
		return personMap.values();
	}

	@Override
	public void update(Person changedPerson) {
		// TODO Auto-generated method stub
		Person foundPerson=null;
		String fileName="persons.txt";
		File f=new File(fileName);
		Map<Integer,Person> personMap=null;
		if(f.exists())
		{
			try(FileInputStream fin=new FileInputStream(f);
					ObjectInputStream in=new ObjectInputStream(fin))
			{
				Object obj=in.readObject();
				personMap=(Map<Integer,Person>)obj;
				
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}
			foundPerson = personMap.get(changedPerson.getPersonId());
			int personId=changedPerson.getPersonId();
			personMap.replace(personId, changedPerson);
			try(FileOutputStream fout=new FileOutputStream("persons.txt");
					ObjectOutputStream out=new ObjectOutputStream(fout))
			{
				out.writeObject(personMap);
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}
			System.out.println("Person Updated Successfully !!");
		}
	}

	@Override
	public void deleteByIdentity(Integer id) {
		// TODO Auto-generated method stub
		String fileName="persons.txt";
		File f=new File(fileName);
		Map<Integer,Person> personMap=null;
		if(f.exists())
		{
			try(FileInputStream fin=new FileInputStream(f);
					ObjectInputStream in=new ObjectInputStream(fin))
			{
				Object obj=in.readObject();
				personMap=(Map<Integer,Person>)obj;
				
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}
			personMap.remove(id);
			try(FileOutputStream fout=new FileOutputStream("persons.txt");
					ObjectOutputStream out=new ObjectOutputStream(fout))
			{
				out.writeObject(personMap);
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}
			System.out.println("Person Deleted Successfully !!");
		}
	}
}
