package collections;

import java.util.Comparator;

import io_prog.Book;

public class BookComparatorTitleDesc implements Comparator<Book> {

	@Override
	public int compare(Book b1, Book b2) {
		// TODO Auto-generated method stub
		String title1=b1.getTitle();
		String title2=b2.getTitle();
		int comparison=title2.compareTo(title1);
		return comparison;
	}
	
}
