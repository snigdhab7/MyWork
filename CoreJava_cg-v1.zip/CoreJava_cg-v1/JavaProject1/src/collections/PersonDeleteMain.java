package collections;

public class PersonDeleteMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DaoInterface<Person,Integer> idao=new PersonDaoImpl();
		Person p=idao.getByIdentity(102);
		if(p!=null)
		{
			idao.deleteByIdentity(p.getPersonId());
		}
		else
		{
			System.out.println("Person Not Found");
		}

	}

}
