package collections;
import java.io.*;
import java.util.*;

import collections.Movie;

public class MovieMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String fileName="src/collections/movies.txt";
		File f=new File(fileName);
		Map<String,Movie> MovieData=new HashMap<>();
		if(f.exists())
		{
			try(Reader fr=new FileReader(f);
					BufferedReader br=new BufferedReader(fr))
			{   
				while(true) {
				String data=br.readLine();
				if(data==null) { break; }
				String[] movieArr=data.split("=");
				Movie m=new Movie(movieArr[0],Integer.parseInt(movieArr[1]));
				MovieData.put(movieArr[0],m);
				}
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		Movie.movieSearch(MovieData);

	}

}
