package collections;

import java.util.*;

public class SystemPropertiesMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties sysProps=System.getProperties();
		Enumeration propNames=sysProps.propertyNames();
		while(propNames.hasMoreElements())
		{
			Object propName=propNames.nextElement();
			String propValue=sysProps.getProperty((String)propName);
			System.out.println(propName+" : "+propValue);
		}

	}

}
