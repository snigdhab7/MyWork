
public class Product {

	private String desciption;
	private float price;
	private int quantity;
	public String getDesciption() {
		return desciption;
	}
	public void setDesciption(String desciption) {
		this.desciption = desciption;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public float getAmount()
	{
		return quantity*price;
	}
	public float getAmount(int d)
	{
		float amt=quantity*price;
		return (amt-(d*amt/100));
	}
	
}
