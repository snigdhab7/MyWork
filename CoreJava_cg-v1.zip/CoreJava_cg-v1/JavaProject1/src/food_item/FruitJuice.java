package food_item;

public class FruitJuice {
	public static void makeOrangeJuice() {
		Fruit orange=new Fruit();
		
	}
}
