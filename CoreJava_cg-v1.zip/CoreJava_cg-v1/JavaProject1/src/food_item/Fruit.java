package food_item;

public class Fruit {

}