package overriding;

public class ShapeMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Shape shapes[]=new Shape[4];
		shapes[0]=new Rectangle("Rectangle 1",10,5);
		shapes[1]=new Rectangle("Rectangle 2",25,15);
		shapes[2]=new Circle("Circle 1",15);
		shapes[3]=new Circle("Circle 2",20);
		
		System.out.println("Drawing all the shapes: ");
		for(Shape sh: shapes)
		{
			sh.draw();
		}
	}

}
