package overriding;

public class Circle extends Shape {
	private int radius;
	public Circle() {
		
	}
	public Circle(String name, int radius) {
		super(name);
		this.radius = radius;
	}
	public void draw() {
		String name=getName();
		System.out.println("Drawing a rectangle "+name+" with Radius: "+radius);
	}
	
}
