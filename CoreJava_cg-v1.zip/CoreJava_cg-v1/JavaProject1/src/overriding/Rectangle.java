package overriding;

public class Rectangle extends Shape {
		private int length, breadth;
		public Rectangle() {
			
		}
		public Rectangle(String name, int length, int breadth) {
			super(name);
			this.length = length;
			this.breadth = breadth;
		}
		public void draw() {
			String name=getName();
			System.out.println("Drawing a rectangle "+name+" with Length: "+length+" and Breadth: "+breadth);
		}
		
}
