
public class ArrayMain {

	/**
	 * @param args
	 */
	public static int[] getSquares(int arr[])
	{
		int size=arr.length;
		int sqrArr[]=new int[size];
		int i=0;
		for(int v:arr)
		{
			sqrArr[i]=v*v;
			i++;
		}
		return sqrArr;
	}
	
	public static int getSum(int arr[])
	{
		int sum=0;
		for (int v:arr)
		{
			sum+=v;
		}
		return sum;
	}
	
	
	public static void main(String[] args) {
		
		/*
		int vals[]={45,34,23,55,64};
		int size=vals.length;
		/*for(int i=0;i<size;i++)
		{ System.out.print(vals[i]+" ");
		} 
		for(int val : vals)
		{ System.out.print(val+" "); } 
		int sum=getSum(vals);
		System.out.println("Sum: "+sum);
		
		int squares[]=getSquares(vals);
		for(int sq:squares)
		{ System.out.print(sq+" "); } */
		Planet planets[]=new Planet[3];
		planets[0]=new Planet();
		planets[1]=new Planet("Mars",2);
		planets[2]=new Planet(2,"Neptune");
		
		for (Planet planet:planets)
		{ System.out.println(planet.getName()+","+planet.getMoons()); }
	}
}

