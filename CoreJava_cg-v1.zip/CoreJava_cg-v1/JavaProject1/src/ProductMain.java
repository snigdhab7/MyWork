
public class ProductMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product p1 = new Product();
		
		/*p1.setDesciption("Soap");
		p1.setPrice(30.00f);
		p1.setQuantity(2);*/
		System.out.println("The price of " + p1.getDesciption() + " is " + p1.getPrice());
		System.out.println("The quantity of " + p1.getDesciption() + " is " + p1.getQuantity());
		System.out.println("The amount of " + p1.getDesciption() + " without discount is " + p1.getAmount());
		System.out.println("The amount of " + p1.getDesciption() + " with discount is " + p1.getAmount(5));
	}

}
