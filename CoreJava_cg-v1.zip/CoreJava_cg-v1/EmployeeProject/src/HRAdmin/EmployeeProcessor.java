package HRAdmin;

public class EmployeeProcessor implements processEmp {

	public static Object processEmpData(ContractEmployees[] empp) {
		// TODO Auto-generated method stub
		float totalSal = 0;
		for(ContractEmployees emp : empp){
			float sal = emp.calculateSalary();
			totalSal += sal;
		}
		return totalSal;
	}
		
}
