package HRAdmin;

public class ContractEmployees extends Employees {
	private float incentives;
	private String contractorName;
	private int contractMonths;
	
	
	public ContractEmployees() throws InvalidSalaryException {
		super();
	}
	
	public ContractEmployees(String name, int empid, float basic,
			float incentives, String contractorName, int contractMonths) throws InvalidSalaryException {
		super(name, empid, basic);
		if (basic<7000)
		{ InvalidSalaryException invsal= new InvalidSalaryException("Permanent Employee Salary should be atleast 7000 !!",basic);
		  throw invsal;
		}
		this.incentives = incentives;
		this.contractorName = contractorName;
		this.contractMonths = contractMonths;
	}
	

	public ContractEmployees(String name, int empid, float basic,
			String contractorName, int contractMonths, float incentives) throws InvalidSalaryException {
		super(name, empid, basic);
		if (basic<7000)
		{ InvalidSalaryException invsal= new InvalidSalaryException("Permanent Employee Salary should be atleast 7000 !!",basic);
		  throw invsal;
		}
		this.contractorName = contractorName;
		this.contractMonths = contractMonths;
		this.incentives = incentives;
	}


	public float getIncentives() {
		return incentives;
	}
	public void setIncentives(float incentives) {
		this.incentives = incentives;
	}
	public String getContractorName() {
		return contractorName;
	}
	public void setContractorName(String contractorName) {
		this.contractorName = contractorName;
	}
	public int getContractMonths() {
		return contractMonths;
	}
	public void setContractMonths(int contractMonths) {
		this.contractMonths = contractMonths;
	}
	
	public float calculateSalary(float basic)
	{ float sal=0.0f;
	  sal+=basic+getIncentives();
	  return sal;
	}

	@Override
	public String toString() {
		return "ContractEmployees [contractMonths=" + contractMonths
				+ ", contractorName=" + contractorName + ", incentives="
				+ incentives + ", toString()=" + super.toString() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + contractMonths;
		result = prime * result
				+ ((contractorName == null) ? 0 : contractorName.hashCode());
		result = prime * result + Float.floatToIntBits(incentives);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		ContractEmployees other = (ContractEmployees) obj;
		if (contractMonths != other.contractMonths)
			return false;
		if (contractorName == null) {
			if (other.contractorName != null)
				return false;
		} else if (!contractorName.equals(other.contractorName))
			return false;
		if (Float.floatToIntBits(incentives) != Float
				.floatToIntBits(other.incentives))
			return false;
		return true;
	}

	@Override
	public float calculateSalary()
	{ float sal=0.0f;
	  sal+=getBasic()+getIncentives();
	  return sal;
	}
	
}
