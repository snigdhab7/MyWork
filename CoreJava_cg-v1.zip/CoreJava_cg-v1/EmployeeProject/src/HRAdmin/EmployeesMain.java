package HRAdmin;

import org.omg.CORBA.DynAnyPackage.Invalid;

public class EmployeesMain extends EmployeeProcessor {
	
	public static float getPerAverageSalary(PermanentEmployees e1[])
	{ float sumsal=0;
	  for (PermanentEmployees emp:e1)
	  { sumsal+=emp.getBasic(); }
	  int size=e1.length;
	  float avgsal=sumsal/(float)size;
	  return avgsal;
	}
	
	public static float getConAverageSalary(ContractEmployees e1[])
	{ float sumsal=0;
	  for (ContractEmployees emp:e1)
	  { sumsal+=emp.getBasic(); }
	  int size=e1.length;
	  float avgsal=sumsal/(float)size;
	  return avgsal;
	}
	
	public static void getPerData(PermanentEmployees e2[],float avg)
	{ int i=0;
	  for (PermanentEmployees emp:e2)
	  { if (emp.getBasic()>avg)
	   { printPerDetails(emp); i++; }
	  }
	}
	
	public static void getConData(ContractEmployees e2[],float avg)
	{ int i=0;
	  for (ContractEmployees emp:e2)
	  { if (emp.getBasic()>avg)
	   { printConDetails(emp); i++; }
	  }
	}
	
	public static void printPerDetails(PermanentEmployees e3)
	{
	 System.out.println("\nName: "+e3.getName()+"\nEmp ID: "+e3.getEmpId()+"\nBasic Salary: "+e3.getBasic()+"\nHRA: "
			 +e3.getHRA()+"\nDA: "+e3.getDA()+"\nTA: "+e3.getTA()+"\nTotal Salary: "+e3.calculateSalary()); 
	}
	
	public static void printConDetails(ContractEmployees e3)
	{
	 System.out.println("\nName: "+e3.getName()+"\nEmp ID: "+e3.getEmpId()+"\nBasic Salary: "+e3.getBasic()+"\nIncentives: "
			 +e3.getIncentives()+"\nTotal Salary: "+e3.calculateSalary()); 
	}


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//PermanentEmployees ep[]=new PermanentEmployees[3];
		ContractEmployees ec[]=new ContractEmployees[3];
		
		try {
		/*ep[0]=new PermanentEmployees("Himanshu Rathod",392432,20000.0f,4000.0f,10000.0f,3000.0f);
		ep[1]=new PermanentEmployees("Aarushi Sinha",342432,5000.0f,4000.0f,10000.0f,3000.0f);
		ep[2]=new PermanentEmployees("Akshay Sethia",345632,9000.0f,4000.0f,10000.0f,3000.0f); */
		
		
		ec[0]=new ContractEmployees("Ramanpreet Kaur Kohli",325442,6000.0f,15000.0f,"Neena Vora",3);
		ec[1]=new ContractEmployees("Snigdha Bose",341332,5000.0f,15000.0f,"Neena Vora",3);
		ec[2]=new ContractEmployees("Arshdeep Kaur Jaggi",342232,7000.0f,15000.0f,"Neena Vora",3);  
		}
		catch(InvalidSalaryException invsal)
		{ String msg=invsal.getMessage();
		  System.out.println(msg);
		}

		
		//System.out.println("Permanent Employees Details :");
		//for (PermanentEmployees emp:ep) {
		//printPerDetails(emp); }
		
		System.out.println("Contract Employees Details :");
		for (ContractEmployees emp:ec) {
		printConDetails(emp); }
		
		//System.out.println("\nAverage Salary (Permanent Employees): "+getPerAverageSalary(ep)+"\n");
		System.out.println("\nAverage Salary (Contract Employees): "+getConAverageSalary(ec)+"\n");
		
		//System.out.println("Permanent Employees earning more than Average Salary are :");
		//getPerData(ep,getPerAverageSalary(ep));
		
		System.out.println("Contract Employees earning more than Average Salary are :");
		getConData(ec,getConAverageSalary(ec));
		
		System.out.println("Total Salary incurred by the organiztaion: "+processEmpData(ec)); 
		
	}

}
