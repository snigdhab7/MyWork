package HRAdmin;

public class InvalidSalaryException extends Exception {
	private float invalidSalary;
		public InvalidSalaryException(String errorMessage,float invalidSalary)
		{ super(errorMessage);
		  this.invalidSalary=invalidSalary;
		}
		public String getMessage() {
			String msg=super.getMessage();
			msg+=" : "+invalidSalary;  
			return msg;
		}
}
