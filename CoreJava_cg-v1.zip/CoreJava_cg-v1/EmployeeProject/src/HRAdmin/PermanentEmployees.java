package HRAdmin;

public class PermanentEmployees extends Employees {
	private float DA,HRA,TA;

	public PermanentEmployees(String name, int empid, float basic, float dA,
			float hRA, float tA) throws InvalidSalaryException {
		super(name, empid, basic);
		if (basic<10000)
		{ InvalidSalaryException invsal= new InvalidSalaryException("Permanent Employee Salary should be atleast 10000 !!",basic);
		  throw invsal;
		}
		DA = dA;
		HRA = hRA;
		TA = tA;
	}
	
	public float calculateSalary()
	{ float sal=0.0f;
	  sal+=getBasic()+getHRA()+getDA()+getTA();
	  return sal;
	  
	}

	public float getDA() {
		return DA;
	}

	public void setDA(float dA) {
		DA = dA;
	}

	public float getHRA() {
		return HRA;
	}

	public void setHRA(float hRA) {
		HRA = hRA;
	}

	public float getTA() {
		return TA;
	}

	public void setTA(float tA) {
		TA = tA;
	}

	@Override
	public String toString() {
		return "PermanentEmployees [DA=" + DA + ", HRA=" + HRA + ", TA=" + TA
				+ ", toString()=" + super.toString() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Float.floatToIntBits(DA);
		result = prime * result + Float.floatToIntBits(HRA);
		result = prime * result + Float.floatToIntBits(TA);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PermanentEmployees other = (PermanentEmployees) obj;
		if (Float.floatToIntBits(DA) != Float.floatToIntBits(other.DA))
			return false;
		if (Float.floatToIntBits(HRA) != Float.floatToIntBits(other.HRA))
			return false;
		if (Float.floatToIntBits(TA) != Float.floatToIntBits(other.TA))
			return false;
		return true;
	}
}
