package HRAdmin;

abstract public class Employees {
	private String name;
	private int empid;
	private float basic;
	private static float avgsal;
	private float salary;
	
	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}
	
	public Employees() throws InvalidSalaryException{}
	
	public Employees(String name,int empid,float basic)
	{ this.name=name; this.empid=empid; this.basic=basic;}
	
	public void setName(String name)
	{ this.name=name; }
	public String getName()
	{ return this.name; }
	public void setEmpId(int empid)
	{ this.empid=empid; }
	public int getEmpId()
	{ return this.empid; }
	public void setBasic (float basic) throws InvalidSalaryException 
	{ this.basic=basic; } 
	public float getBasic()
	{ return this.basic; }
	
	abstract public float calculateSalary();

	@Override
	public String toString() {
		return "Employees [basic=" + basic + ", empid=" + empid + ", name="
				+ name + ", salary=" + salary + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(basic);
		result = prime * result + empid;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + Float.floatToIntBits(salary);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employees other = (Employees) obj;
		if (Float.floatToIntBits(basic) != Float.floatToIntBits(other.basic))
			return false;
		if (empid != other.empid)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (Float.floatToIntBits(salary) != Float.floatToIntBits(other.salary))
			return false;
		return true;
	}
	
	
}
