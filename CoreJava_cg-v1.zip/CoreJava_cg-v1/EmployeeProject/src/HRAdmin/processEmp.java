package HRAdmin;

public interface processEmp {
	static Object processEmpData(PermanentEmployees[] empp) {
		// TODO Auto-generated method stub
		return null;
	}
}
