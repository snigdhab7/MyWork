
public class CreateAccount {
	private String name;
	private int custID;
	private int accNO;
	private String Address;
	private char gender;
	private int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCustID() {
		return custID;
	}
	public void setCustID(int custID) {
		this.custID = custID;
	}
	public int getAccNO() {
		return accNO;
	}
	public void setAccNO(int accNO) {
		this.accNO = accNO;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public CreateAccount(String name, int custID, int accNO, String address, char gender, int age) {
		super();
		this.name = name;
		this.custID = custID;
		this.accNO = accNO;
		Address = address;
		this.gender = gender;
		this.age = age;
	}

}
