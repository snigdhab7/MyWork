package Lab1;

public class Exercise2Main {

	public static void main(String[] args) {
		Exercise2 e2=new Exercise2();
		int diff=e2.calculateDifference(20);
		System.out.println("The Differnce is "+diff);
	}

}
