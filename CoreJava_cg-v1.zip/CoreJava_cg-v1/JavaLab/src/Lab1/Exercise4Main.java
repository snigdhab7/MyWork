package Lab1;

public class Exercise4Main {

	public static void main(String[] args) {
		Exercise4 e4=new Exercise4();
		boolean b=e4.checkNumber(13);
		if(b==true)
		{ System.out.println("The number is a power of 2"); }
		else
		{ System.out.println("The number is not a power of 2"); }

	}

}
