package Lab1;

public class Exercise2 {
	public int calculateDifference(int n)
	{ int sumsq=0,sqsum=0,sum=0;
	  for (int i=1;i<=n;i++)
	  { sumsq+=(i*i); 
	    sum+=i; }
	  sqsum=(sum*sum);
	  System.out.println(sumsq+" "+sqsum);
	  int diff=sumsq-sqsum;
	  return diff;
	}
 
}
