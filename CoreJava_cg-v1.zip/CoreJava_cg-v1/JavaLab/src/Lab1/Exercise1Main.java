package Lab1;

public class Exercise1Main {

	public static void main(String[] args) {
		Exercise1 e1= new Exercise1();
		int s=e1.calculateSum(20);
		System.out.println("The sum of Natural Numbers till 20 which are divisible by 3 or 5 is: "+s);

	}

}
