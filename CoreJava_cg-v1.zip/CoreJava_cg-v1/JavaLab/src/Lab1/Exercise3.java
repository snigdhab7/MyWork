package Lab1;

public class Exercise3 {
	public boolean checkNumber(int n)
	{ boolean flag=true; int n1=n,size=0;
	  while(n1!=0)
	  { size++; n1/=10; }
	  int arr[]=new int[size];
	  int i=size-1;
	  while(n!=0)
	  { arr[i]=n%10;
	    n=n/10;
	    i--;
	  }
	  for(int j=size-1;j>=1;j--)
	  { if(arr[j]<arr[j-1])
	    { flag=false; break; } 
	  }
	  return flag;
}
}
