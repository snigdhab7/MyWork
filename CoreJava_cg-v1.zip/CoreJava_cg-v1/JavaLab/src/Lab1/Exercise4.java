package Lab1;

public class Exercise4 {
	public boolean checkNumber(int n)
	{ boolean flag=false; 
	  for(int i=0;i<=n/2;i++)
	  {  if(n==Math.pow(2, i))
	    {  flag=true; break; }
	  }
	  return flag;
	}
}
