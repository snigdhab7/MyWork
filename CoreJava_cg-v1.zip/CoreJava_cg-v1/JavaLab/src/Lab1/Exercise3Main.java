package Lab1;

public class Exercise3Main {

	public static void main(String[] args) {
		Exercise3 e3=new Exercise3();
		if(e3.checkNumber(1534)==true)
		{ System.out.println("The number is Increasing"); }
		else
		{ System.out.println("The number is not Increasing"); }
	}

}
