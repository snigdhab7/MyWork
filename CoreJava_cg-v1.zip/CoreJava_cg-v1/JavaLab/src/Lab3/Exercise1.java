package Lab3;

public class Exercise1 {
	public int getSecondSmallest(int[] ar)
	{ int size=ar.length;
	  for(int i=0;i<size-1;i++)
	  { for(int j=i+1;j<size;j++)
	    { int temp;
		  if(ar[i]>ar[j])
		  { temp=ar[i]; ar[i]=ar[j]; ar[j]=temp; }
	    }
	  }
	  return ar[1];
	  }
	}
