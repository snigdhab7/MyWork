package Lab3;

public class Exercise3 {
	public int[] getSorted(int ar[])
	{ int size=ar.length;
	  int resAr[]=new int[size];
	  for(int i=0;i<size;i++)
	  { int n=0,n1=ar[i],cd=0,n2=ar[i];
	    while(n1!=0)
	    { cd++; n1/=10; }
	    while(n2!=0)
	    { n+=(n2%10)*Math.pow(10, cd-1);
	      cd--;
	      n2=n2/10;
	    }
	    resAr[i]=n;
	  }
	    for(int i=0;i<size-1;i++)
	    { for(int j=0;j<size;j++)
	      { if(resAr[i]>resAr[j])
	        { resAr[i]=resAr[i]+resAr[j];
	          resAr[j]=resAr[i]-resAr[j];
	          resAr[i]=resAr[i]-resAr[j];
	        }
	      }
	    }
	   return resAr;
	  }
	}
