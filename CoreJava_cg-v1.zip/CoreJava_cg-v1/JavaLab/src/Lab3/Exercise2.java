package Lab3;

public class Exercise2 {
	public String[] sortStrings(String str[])
	{ int size=str.length;
	  for(int i=0;i<size-1;i++)
	  {
		 for(int j=i+1;j<size;j++)
		 { String temp;
			 if(str[i].compareTo(str[j])>0)
			 { temp=str[i];
			    str[i]=str[j];
			    str[j]=temp;
			 }
		 }
		 }
	  if(size%2==0)
	  { for(int i=0;i<size/2;i++)
	    { str[i]=str[i].toUpperCase(); 
	      str[size-i-1]=str[size-i-1].toLowerCase();
	    }
	  }
	  else
	  { for(int i=0;i<size/2+1;i++)
	    { str[i]=str[i].toUpperCase(); 
	      str[size-i-1]=str[size-i-1].toLowerCase();
	    }
	  }
	  return str;
	  }
}
