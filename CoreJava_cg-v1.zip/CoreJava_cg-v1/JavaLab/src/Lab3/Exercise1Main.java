package Lab3;

public class Exercise1Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {12,43,24,54,34};
		Exercise1 e1=new Exercise1();
		int secondSmallest=e1.getSecondSmallest(arr);
		System.out.println("The Second Smallest element of the array is "+secondSmallest);
	}

}
