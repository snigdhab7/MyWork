package Lab3;

public class Exercise2Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String strings[]= {"Himanshu","Snigdha","Arshdeep","Akshay","Ramanpreet","Aarushi","Nikhil","Sahil"};
		Exercise2 e2=new Exercise2();
		String[] stringsSorted=e2.sortStrings(strings);
		System.out.println("The Resultant String Array is as follows:");
		for(int i=0;i<stringsSorted.length;i++)
		{ System.out.print(stringsSorted[i]+" "); }
	}
}
