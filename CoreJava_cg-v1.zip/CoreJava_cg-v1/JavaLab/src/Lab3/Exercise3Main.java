package Lab3;

public class Exercise3Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {12,32,43,23,65,75,44};
		Exercise3 e3=new Exercise3();
		int[] resArr=e3.getSorted(arr);
		System.out.println("The Resultant Array is :");
		for(int i=0;i<arr.length;i++)
		{ System.out.print(resArr[i]+" "); }
	}

}
