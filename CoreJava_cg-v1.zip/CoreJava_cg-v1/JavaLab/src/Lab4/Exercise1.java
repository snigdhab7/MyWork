package Lab4;

public class Exercise1 {
	public int findSumOfCubes(int num)
	{ int n=num,sum=0;
	  while(n!=0)
	  { sum+=Math.pow(n%10, 3); 
	    n=n/10; }
	  return sum;
	  }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Exercise1 e1=new Exercise1();
		int number=38743;
		int s=e1.findSumOfCubes(number);
		System.out.println("The desired sum of cubes of digits of number : "+s);
	}

}
