package Lab5;

import java.util.Scanner;

public class Exercise5Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter your age: ");
		int age=0;
		try {
			age=s.nextInt();
			checkAge(age);
		} catch(InvalidAge e)
		{ String msg=e.getMessage();
		  System.out.println(msg); 
		}
		finally
		{   if(age>15)
			{ System.out.println("Age : "+age); }
		}
		s.close();
	}

	private static void checkAge(int age) throws InvalidAge {
		// TODO Auto-generated method stub
		if(age<=15)
		{ InvalidAge invage=new InvalidAge("Age should be above 15 !!",age); 
		  throw invage;
		}
	}
}

