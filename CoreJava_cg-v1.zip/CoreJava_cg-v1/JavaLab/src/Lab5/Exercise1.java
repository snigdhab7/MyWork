package Lab5;

public class Exercise1 {
	public String simulateTrafficLight(int n)
	{ String res;
	  switch(n)
	  { case 1: res="Stop"; break;
	  case 2: res="Ready"; break;
	  case 3: res="Go"; break;
	  default: res="Choose Valid Option !!";
	  }
	  return res;
	}

}
