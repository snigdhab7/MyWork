package Lab5;

import java.util.Scanner;

public class Exercise4Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		String fname=null,lname=null;
		try { 
		System.out.println("Enter First Name:");
		fname=s.nextLine();
		System.out.println("Enter Last Name:");
		lname=s.nextLine();
		checkInvalidName(fname,lname);
		} catch(InvalidFullName e)
		  { String m=e.getMessage(); 
		    System.out.println(m); }
		finally {
			if(fname.length()!=0 && lname.length()!=0)
			{ System.out.println("Full Name: "+fname+" "+lname); }
		}
		
		s.close();
	}

	private static void checkInvalidName(String fn1,String ln1) throws InvalidFullName {
		if (fn1.length()==0 || ln1.length()==0)
		{ InvalidFullName fn=new InvalidFullName("Please enter your Full Name !!"); 
		  throw fn;
	}
}
}


