package Lab5;

public class InvalidFullName extends Exception {
	public InvalidFullName(String errorMessage)
	{ super(errorMessage); }
	public String getMessage()
	{ String msg=super.getMessage(); 
	  return msg;
	}
}
