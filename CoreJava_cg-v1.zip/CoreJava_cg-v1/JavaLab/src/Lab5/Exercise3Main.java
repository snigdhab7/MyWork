package Lab5;
import java.util.*;

public class Exercise3Main {
	
	public boolean checkPrime(int n)
	{ boolean flag=true;
	  if(n==1)
	  { return false; }
	  else {
	  for(int i=2;i<=n/2;i++)
	  { if(n%i==0)
	    { flag=false; break; }
	  }
	  }
	  return flag;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		Exercise3Main e3=new Exercise3Main();
		System.out.println("Enter a positive integer: ");
		int num=s.nextInt();
		System.out.println("The Prime numbers up to the input integer are: ");
		for(int i=1;i<=num;i++)
		{ if(e3.checkPrime(i)==true)
		  { System.out.print(i+" "); }
		}
		s.close();
	}

}
