package Lab5;

import java.util.Scanner;

public class Exercise2Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Exercise2 e2=new Exercise2();
		Scanner s=new Scanner(System.in);
		int pos=s.nextInt();
		System.out.println("The Fibonacci Number using Recursive Method : "+e2.recursiveFibonacci(pos));
		System.out.println("The Fibonacci Number using Non-Recursive Method : "+e2.nonRecursiveFibonacci(pos));
		s.close();
	}

}
