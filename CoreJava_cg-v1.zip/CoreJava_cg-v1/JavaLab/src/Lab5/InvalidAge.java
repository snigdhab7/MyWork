package Lab5;

public class InvalidAge extends Exception {
	private int age;
	public InvalidAge(String errorMessage,int a)
	{ super(errorMessage);
	  this.age=a; 
	}
	public String getMessage()
	{ String msg=super.getMessage();  
	  msg+=" : "+age;
	  return msg;
	}
}
