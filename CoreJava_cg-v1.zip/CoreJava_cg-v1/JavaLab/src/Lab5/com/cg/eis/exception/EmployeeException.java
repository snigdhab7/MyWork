package Lab5.com.cg.eis.exception;

public class EmployeeException extends Exception {
	private float salary;
	public EmployeeException(String errorMessage, float salary)
	{ super(errorMessage); 
	  this.salary=salary;
	}
	public String getMessage()
	{ String msg=super.getMessage();
	  msg+=" : "+salary;
	  return msg;
	}
}
