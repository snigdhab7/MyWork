package Lab5.com.cg.eis.exception;

import java.util.Scanner;

public class Exercise6Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		String ename; int eid; float sal = 0;
		System.out.println("Enter Employee Name: ");
		ename=s.nextLine();
		System.out.println("Enter Employee ID: ");
		eid=s.nextInt();
		try {
			System.out.println("Enter Employee Salary: ");
			sal=s.nextFloat();	
			checkSalary(sal);
		} catch (EmployeeException e)
		{ 
			String msg=e.getMessage();
			System.out.println(msg);
		}
		finally
		{ 
			if(sal>=3000)
			{ System.out.print("Employee Name: "+ename+"\nEmployee ID: "+eid+"\nEmployee Salary: "+sal); }
		}
		s.close();

	}
	
	public static void checkSalary(float salary) throws EmployeeException
	{ if (salary<3000)
	  { EmployeeException ee=new EmployeeException("Salary is less than 3000 !!",salary);  
	    throw ee;
	  }
	}
}
