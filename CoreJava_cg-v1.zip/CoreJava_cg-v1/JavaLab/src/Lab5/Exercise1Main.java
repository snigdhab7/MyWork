package Lab5;

import java.util.Scanner;

public class Exercise1Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Traffic Light Simulator :\n1.Red\n2.Yellow\n3.Green\nEnter Your Choice:");
		Scanner s =new Scanner(System.in);
		int number=s.nextInt();
		Exercise1 e1=new Exercise1();
		String message=e1.simulateTrafficLight(number);
		System.out.println("Message : "+message);
		s.close();
		
	}

}
