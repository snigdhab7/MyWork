package Lab6;

public class Exercise1Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String

	}

}
