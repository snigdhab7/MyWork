package Lab6;

import java.util.Scanner;

public class Exercise5Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr=new Scanner(System.in);
		String str=scr.nextLine();
		int flag=1;
		for(int i=0;i<str.length()-1;i++)
		{
			if((int)str.charAt(i)>(int)str.charAt(i+1))
			{ flag=0; break; }
		}
		if(flag==1)
		{
			System.out.println("Positive String");
		}
		else
		{
			System.out.println("Not a Positive String");
		}
		scr.close();
	}

}
