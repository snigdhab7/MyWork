package Lab2;

import java.util.*;

public class LibraryMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		
		Item b1=new Book(012, "2 States", 5, 17, 24, 1, 2, 2020, 2020, "Chetan Bhagat");
		Item jp1=new JournalPaper(013,"Mining GPS Data",3,24,1,2,2,2020,2020,"John Lewis",2014);
		Item v1=new Video(014,"SOTY 2",6,20,27,1,1,2020,2020,130,"Karan Johar","Drama",2019);
		Item cd1=new CD(015,"Bollywood Songs 2019",8,2,9,2,2,2020,2020,56,"AR Rahman","Romantic");
		
		System.out.println("Welcome to Library Management System");
		System.out.println("Main Menu :");
		System.out.print("1. Books\n2. Journal Papers\n3. Videos\n4. CDs\nChoose an option(1-4):");
		try {
		int ch=s.nextInt();
		switch(ch)
		{ case 1: b1.print(); break;
		case 2: jp1.print(); break;
		case 3: v1.print(); break;
		case 4: cd1.print(); break; 
		default: System.out.println("Enter a Valid Option !!"); break;
		}
		} catch(InputMismatchException e)
		{ System.out.println("Enter a Valid Option !!"); }
		s.close();

	}

}
