package Lab2;

public class Book extends WrittenItem {

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Book(int uid, String title, int noOfCopies, int iday, int oday, int imonth, int omonth, int iyear, int oyear,
			String author) {
		super(uid, title, noOfCopies, iday, oday, imonth, omonth, iyear, oyear, author);
		// TODO Auto-generated constructor stub
	}

	public Book(int uid, String title, int noOfCopies, int iday, int oday, int imonth, int omonth, int iyear,
			int oyear) {
		super(uid, title, noOfCopies, iday, oday, imonth, omonth, iyear, oyear);
		// TODO Auto-generated constructor stub
	}

	public Book(String author) {
		super(author);
		// TODO Auto-generated constructor stub
	}
	
	public void print()
	{ super.print(); 
	  System.out.println("\nAuthor: "+getAuthor());
	}
}
