package Lab2;

public class JournalPaper extends WrittenItem {
	private int year;

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public JournalPaper(int year) {
		super();
		this.year = year;
	}

	public JournalPaper(String author, int year) {
		super(author);
		this.year = year;
	}

	public JournalPaper(int uid, String title, int noOfCopies, int iday, int oday, int imonth, int omonth, int iyear,
			int oyear, String author, int year) {
		super(uid, title, noOfCopies, iday, oday, imonth, omonth, iyear, oyear, author);
		this.year = year;
	}
	
	public void print()
	{ super.print(); 
	  System.out.println("\nAuthor: "+getAuthor()+"\nYear Published: "+getYear());
	}

}
