package Lab2;

abstract public class MediaItem extends Item {
	private int runtime;

	public int getRuntime() {
		return runtime;
	}

	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}

	public MediaItem(int runtime) {
		super();
		this.runtime = runtime;
	}

	public MediaItem(int uid, String title, int noOfCopies, int iday, int oday, int imonth, int omonth, int iyear,
			int oyear, int runtime) {
		super(uid, title, noOfCopies, iday, oday, imonth, omonth, iyear, oyear);
		this.runtime = runtime;
	}

	public String toString() {
		return "MediaItem [runtime=" + runtime + ", getIday()=" + getIday() + ", getOday()=" + getOday()
				+ ", getImonth()=" + getImonth() + ", getOmonth()=" + getOmonth() + ", getIyear()=" + getIyear()
				+ ", getOyear()=" + getOyear() + ", getUid()=" + getUid() + ", getTitle()=" + getTitle()
				+ ", getNoOfCopies()=" + getNoOfCopies() + ", toString()=" + super.toString() + ", hashCode()="
				+ hashCode() + ", getClass()=" + getClass() + "]";
	}

	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + runtime;
		return result;
	}

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		MediaItem other = (MediaItem) obj;
		if (runtime != other.runtime)
			return false;
		return true;
	}
	
	public void print()
	{ super.print(); }

}
