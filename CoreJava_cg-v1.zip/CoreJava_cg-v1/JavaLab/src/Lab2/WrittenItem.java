package Lab2;

abstract public class WrittenItem extends Item {
	private String author;

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public WrittenItem(int uid, String title, int noOfCopies, int iday, int oday, int imonth, int omonth, int iyear,
			int oyear, String author) {
		super(uid, title, noOfCopies, iday, oday, imonth, omonth, iyear, oyear);
		this.author = author;
	}

	public WrittenItem(String author) {
		super();
		this.author = author;
	}

	public String toString() {
		return "WrittenItem [author=" + author + "]";
	}

	public WrittenItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	public WrittenItem(int uid, String title, int noOfCopies, int iday, int oday, int imonth, int omonth, int iyear,
			int oyear) {
		super(uid, title, noOfCopies, iday, oday, imonth, omonth, iyear, oyear);
		// TODO Auto-generated constructor stub
	}

	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((author == null) ? 0 : author.hashCode());
		return result;
	}

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		WrittenItem other = (WrittenItem) obj;
		if (author == null) {
			if (other.author != null)
				return false;
		} else if (!author.equals(other.author))
			return false;
		return true;
	}
	
	public void print()
	{ super.print(); }

}
