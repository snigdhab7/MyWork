package Lab2;

abstract public class Item {
	private int uid;
	private String title;
	private int noOfCopies;
	private int iday,oday,imonth,omonth,iyear,oyear;
	
	public int getIday() {
		return iday;
	}

	public void setIday(int iday) {
		this.iday = iday;
	}

	public int getOday() {
		return oday;
	}

	public void setOday(int oday) {
		this.oday = oday;
	}

	public int getImonth() {
		return imonth;
	}

	public void setImonth(int imonth) {
		this.imonth = imonth;
	}

	public int getOmonth() {
		return omonth;
	}

	public void setOmonth(int omonth) {
		this.omonth = omonth;
	}

	public int getIyear() {
		return iyear;
	}

	public void setIyear(int iyear) {
		this.iyear = iyear;
	}

	public int getOyear() {
		return oyear;
	}

	public void setOyear(int oyear) {
		this.oyear = oyear;
	}

	public Item() {
		super();
	}

	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getNoOfCopies() {
		return noOfCopies;
	}
	public void setNoOfCopies(int noOfCopies) {
		this.noOfCopies = noOfCopies;
	}
	
	public void print()
	{ System.out.print("Item Details\n"+"UID: "+uid+"\nTitle: "+title+"\nNumber of copies: "+noOfCopies); 
	  System.out.print("\nCheckIn Date: "+checkIn(iday,imonth,iyear)+"\nCheckOut Date: "+checkOut(oday,omonth,oyear));
	}
	
	public String checkIn(int day,int month,int year)
	{ iday=day; imonth=month; iyear=year; 
	  String cidate=iday+"/"+imonth+"/"+iyear;
	  return cidate;
	}
	
	public String checkOut(int day,int month,int year)
	{ oday=day; omonth=month; oyear=year; 
	  String codate=oday+"/"+omonth+"/"+oyear;
	  return codate;
	}
	
	public void addItem()
	{ noOfCopies++; }

	public Item(int uid, String title, int noOfCopies, int iday, int oday, int imonth, int omonth, int iyear,
			int oyear) {
		super();
		this.uid = uid;
		this.title = title;
		this.noOfCopies = noOfCopies;
		this.iday = iday;
		this.oday = oday;
		this.imonth = imonth;
		this.omonth = omonth;
		this.iyear = iyear;
		this.oyear = oyear;
	}

	public String toString() {
		return "Item [uid=" + uid + ", title=" + title + ", noOfCopies=" + noOfCopies + ", iday=" + iday + ", oday="
				+ oday + ", imonth=" + imonth + ", omonth=" + omonth + ", iyear=" + iyear + ", oyear=" + oyear + "]";
	}

	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + iday;
		result = prime * result + imonth;
		result = prime * result + iyear;
		result = prime * result + noOfCopies;
		result = prime * result + oday;
		result = prime * result + omonth;
		result = prime * result + oyear;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + uid;
		return result;
	}

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (iday != other.iday)
			return false;
		if (imonth != other.imonth)
			return false;
		if (iyear != other.iyear)
			return false;
		if (noOfCopies != other.noOfCopies)
			return false;
		if (oday != other.oday)
			return false;
		if (omonth != other.omonth)
			return false;
		if (oyear != other.oyear)
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		if (uid != other.uid)
			return false;
		return true;
	}

}
